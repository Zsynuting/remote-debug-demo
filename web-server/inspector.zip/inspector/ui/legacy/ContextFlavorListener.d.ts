export interface ContextFlavorListener {
    flavorChanged(object: Object | null): void;
}
