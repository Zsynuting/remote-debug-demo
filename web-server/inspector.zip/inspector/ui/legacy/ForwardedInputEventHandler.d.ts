export declare class ForwardedInputEventHandler {
    constructor();
    private onKeyEventUnhandled;
}
