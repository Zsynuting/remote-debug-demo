export interface App {
    presentUI(document: Document): void;
}
