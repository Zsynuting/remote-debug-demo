import './DOMExtension.js';
import * as DOMExtension from './DOMExtension.js';
export { DOMExtension, };
