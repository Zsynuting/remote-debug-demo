export declare function platform(): string;
export declare function isMac(): boolean;
export declare function isWin(): boolean;
export declare function setPlatformForTests(platform: string): void;
export declare function isCustomDevtoolsFrontend(): boolean;
export declare function fontFamily(): string;
