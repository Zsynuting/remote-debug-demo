export declare const addAll: <T>(set: Set<T>, iterable: Iterable<T>) => void;
export declare const isEqual: <T>(setA: Set<T>, setB: Set<T>) => boolean;
