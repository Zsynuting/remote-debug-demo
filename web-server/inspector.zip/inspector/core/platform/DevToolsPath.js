// Copyright 2021 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.
class UrlStringTag {
    urlTag;
}
export const EmptyUrlString = '';
class RawPathStringTag {
    rawPathTag;
}
export const EmptyRawPathString = '';
class EncodedPathStringTag {
    encodedPathTag;
}
export const EmptyEncodedPathString = '';
//# sourceMappingURL=DevToolsPath.js.map